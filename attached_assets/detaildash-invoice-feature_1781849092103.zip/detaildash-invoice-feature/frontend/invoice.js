function printInvoice() {
    window.print();
}